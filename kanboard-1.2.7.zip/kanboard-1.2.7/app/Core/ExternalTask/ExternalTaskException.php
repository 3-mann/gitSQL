<?php

namespace Kanboard\Core\ExternalTask;

use Exception;

/**
 * Class NotFoundException
 *
 * @package Kanboard\Core\ExternalTask
 * @author  Frederic Guillot
 */
class ExternalTaskException extends Exception
{
}
