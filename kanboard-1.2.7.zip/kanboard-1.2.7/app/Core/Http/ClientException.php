<?php

namespace Kanboard\Core\Http;

use Exception;

class ClientException extends Exception
{
}
