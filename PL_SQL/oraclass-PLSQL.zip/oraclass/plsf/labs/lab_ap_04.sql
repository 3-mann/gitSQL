create table temp 
(num_store number(7,2),
char_store varchar2(35),
date_store date);
