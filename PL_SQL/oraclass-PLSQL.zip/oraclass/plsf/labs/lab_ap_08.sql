DROP TABLE analysis;
CREATE TABLE analysis
  (ename VARCHAR2(20), years NUMBER(2), sal NUMBER(8,2)
  );