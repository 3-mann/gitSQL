SELECT name, type, plsql_code_type as code_type, 
plsql_optimize_level as opt_lvl
FROM   user_plsql_object_settings;

