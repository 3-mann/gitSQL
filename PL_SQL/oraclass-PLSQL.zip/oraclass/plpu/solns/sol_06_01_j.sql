EXECUTE table_pkg.remove('my_contacts')
DESCRIBE my_contacts
