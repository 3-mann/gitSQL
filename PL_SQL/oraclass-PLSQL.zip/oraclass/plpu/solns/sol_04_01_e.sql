SELECT *
FROM employees
WHERE last_name = 'Joplin';