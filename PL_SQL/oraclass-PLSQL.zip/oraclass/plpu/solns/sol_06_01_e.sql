SET SERVEROUTPUT ON

BEGIN
  table_pkg.add_row('my_contacts','1,''Lauran Serhal''','id, name');
  table_pkg.add_row('my_contacts','2,''Nancy''','id, name');
  table_pkg.add_row('my_contacts','3,''Sunitha Patel''','id,name');
  table_pkg.add_row('my_contacts','4,''Valli Pataballa''','id,name');
END;
/

