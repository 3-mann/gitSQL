SET SERVEROUTPUT ON
EXEC table_pkg.upd_row('my_contacts','name=''Nancy Greenberg''','id=2')
