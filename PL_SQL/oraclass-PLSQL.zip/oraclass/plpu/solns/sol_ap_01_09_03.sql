UPDATE jobs 
  SET min_salary = 7000, max_salary = 18000 
  WHERE job_id = 'SY_ANAL';
