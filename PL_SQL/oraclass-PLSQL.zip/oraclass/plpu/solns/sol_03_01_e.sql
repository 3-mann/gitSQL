SELECT *
FROM jobs
WHERE job_id = 'IT_SYSAN';