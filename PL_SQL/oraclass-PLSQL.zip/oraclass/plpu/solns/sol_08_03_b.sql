BEGIN
  emp_pkg.add_employee('Eleanor', 'Beh', 'EBEH',
                        p_job => 'IT_PROG', p_sal => 5000);
END;
/
