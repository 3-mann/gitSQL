DESCRIBE my_contacts
