EXECUTE emp_pkg.add_employee('Eleanor', 'Beh', 30)
