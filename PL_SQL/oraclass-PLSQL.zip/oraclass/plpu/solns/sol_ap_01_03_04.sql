SELECT *   FROM   job_history
WHERE  employee_id = 106;

SELECT job_id, salary   FROM   employees
WHERE  employee_id = 106;

COMMIT;
