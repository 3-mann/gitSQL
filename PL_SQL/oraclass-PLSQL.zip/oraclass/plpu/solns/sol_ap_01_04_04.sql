EXECUTE upd_jobsal('SY_ANAL', 7000, 14000)
