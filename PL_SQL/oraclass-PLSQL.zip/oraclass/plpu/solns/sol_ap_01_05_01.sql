ALTER TRIGGER secure_employees DISABLE;
