EXECUTE emp_pkg.add_employee('James', 'Bond', 15)
