SELECT object_name, object_type, status
FROM USER_OBJECTS
WHERE status = 'INVALID';
