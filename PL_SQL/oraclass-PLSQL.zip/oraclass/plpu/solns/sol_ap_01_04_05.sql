SELECT *
FROM  jobs
WHERE job_id = 'SY_ANAL';
