SET SERVEROUTPUT ON
EXECUTE table_pkg.del_row('my_contacts', 'id=3')
