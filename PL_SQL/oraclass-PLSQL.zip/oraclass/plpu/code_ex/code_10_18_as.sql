ALTER SESSION 
SET plsql_warnings =	'enable:severe', 'enable:performance', 'disable:informational';