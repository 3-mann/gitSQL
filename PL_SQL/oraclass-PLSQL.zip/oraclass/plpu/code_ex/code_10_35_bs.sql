SELECT * 
FROM user_errors
WHERE name = 'P';
