EXECUTE deptree_fill('TABLE', 'ORA61', 'EMPLOYEES')
