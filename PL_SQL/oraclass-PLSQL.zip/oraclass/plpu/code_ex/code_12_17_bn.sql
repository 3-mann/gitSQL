SELECT status FROM user_objects
  WHERE object_name = 'P';
