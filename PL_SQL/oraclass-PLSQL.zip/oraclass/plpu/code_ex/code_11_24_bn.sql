SELECT text FROM user_source
WHERE name = 'NEW_PROC';
