ALTER SESSION 
SET plsql_warnings = 'enable:severe';