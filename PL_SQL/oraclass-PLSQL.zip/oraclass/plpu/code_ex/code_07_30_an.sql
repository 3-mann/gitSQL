-- disable the triggers before running the
-- code shown in the slide.

ALTER TRIGGER update_job_history DISABLE;
ALTER TRIGGER check_salary_trg DISBALE;

