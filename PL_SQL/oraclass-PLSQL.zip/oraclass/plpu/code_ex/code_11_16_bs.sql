-- Run code_11_16_as.sql before running this code example. Using Oracle Database 11g R2
SET SERVEROUTPUT ON
CALL circle_area(50);
/