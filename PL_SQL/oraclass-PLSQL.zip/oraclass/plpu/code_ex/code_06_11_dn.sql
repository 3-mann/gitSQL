EXECUTE add_col('employee_names', 'salary number(8,2)')
