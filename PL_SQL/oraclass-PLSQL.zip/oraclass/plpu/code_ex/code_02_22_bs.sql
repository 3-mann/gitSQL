SELECT text
FROM   user_source
WHERE  type = 'FUNCTION'
ORDER BY line; 
