-- Run this code example before code_10_35_as.sql.

CREATE TABLE t (col_a NUMBER);
