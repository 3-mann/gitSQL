-- Test the compile_code procedure from code_10_32_s.sql

EXECUTE DBMS_WARNING.SET_WARNING_SETTING_STRING('ENABLE:ALL', 'SESSION');
