DESCRIBE user_triggers
