-- You must run code_01_30_s.sql before attempting to run this code example which 
-- generates an expected error. 

EXECUTE add_dept(p_name=>'new dept', 'new location')