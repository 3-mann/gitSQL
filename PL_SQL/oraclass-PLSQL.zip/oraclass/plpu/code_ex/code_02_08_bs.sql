-- You must run code_02_08_as.sql before running this code example. 

SET SERVEROUTPUT ON

EXECUTE DBMS_OUTPUT.PUT_LINE(get_sal(100))
