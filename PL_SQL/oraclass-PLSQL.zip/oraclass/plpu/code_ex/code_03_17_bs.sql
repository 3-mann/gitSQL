EXECUTE comm_pkg.reset_comm(0.15)
