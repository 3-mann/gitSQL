@code_10_32_s.sql
