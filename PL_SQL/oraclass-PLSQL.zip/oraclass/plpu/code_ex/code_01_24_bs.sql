-- You must run code_01_24_as.sql before running this code example. 

EXECUTE raise_salary(176, 10)
