
SELECT name, type, plsql_ccflags
FROM user_plsql_object_settings;