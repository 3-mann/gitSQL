-- Run this code example before code_09_18_as,sql and code_09_18_bs.sql

CREATE TABLE log_trig_table(
  user_id  VARCHAR2(30),
  log_date DATE,
   action  VARCHAR2(40))
/