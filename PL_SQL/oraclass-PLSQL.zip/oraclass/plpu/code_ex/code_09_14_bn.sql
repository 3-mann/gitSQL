SELECT employee_id, first_name, last_name, job_id, department_id, salary
FROM employees
WHERE last_name = 'Stiles';
