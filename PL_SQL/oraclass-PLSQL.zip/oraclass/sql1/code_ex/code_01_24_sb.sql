SELECT DISTINCT department_id
FROM   employees;