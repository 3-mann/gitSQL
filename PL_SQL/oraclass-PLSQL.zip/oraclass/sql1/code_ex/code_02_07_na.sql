SELECT last_name, job_id, department_id
FROM   employees
WHERE  last_name = 'WHALEN';
