SELECT last_name ||': 1 Month salary = '||salary Monthly
FROM   employees;